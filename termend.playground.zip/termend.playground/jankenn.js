function janken(myhand) {

    var handArrey = ["ぐー.", "猪木.", "パー"]
    console.log("プレイヤーの手は" + handArrey[myhand])

    var random = Math.random() * 100;
    console.log(random);

    var randomInt = Math.floor(random);
    console.log(randomInt);

    var computerHand = randomInt % 3;
    console.log("コンピュータの手は" + handArrey[computerHand]);

    var victory = 0;

    victory = (myhand - computerHand + 3) % 3;

    var messageArray = ["あいこです（笑）", "勝ちです！", "負けです（泣）"];
    alert("あなたの手は" + handArrey[myhand] + "コンピュータの手は" + handArrey[computerHand] + "なので" + messageArray[victory]);
}